<?php
// Use the header function to perform the redirect
header("Location: http://10.3.13.87/storehl/");
exit(); // Make sure to call exit() after the header to stop further script execution
?>