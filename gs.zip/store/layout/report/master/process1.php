<h1>process 1</h1>
<?php
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
echo $start_date;
echo "<br>";
echo $end_date;
?>