<?php
//$company_name=$_POST['company'];
//$user_name=$_POST['username'];
$user_password=$_POST['password'];
//$user_remember=$_POST['remember'];

echo "$company_name, $user_name, $user_password, $user_remember";
?>
