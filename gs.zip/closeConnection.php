// Close the database connection when you're done
mysqli_close($connection);
?>

<?php  