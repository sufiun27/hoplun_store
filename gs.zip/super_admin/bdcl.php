<?php
session_start();
$_SESSION['company'] = 'bdcl';
header("Location: http://10.3.13.87/storehl/store/layout/start/");
?>


