<?php

/// need to also change it

$servername = "10.3.13.87";
$username = "sa";
$password = "sa@123";
?>