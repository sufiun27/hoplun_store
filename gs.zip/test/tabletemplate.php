<style>
    td{
        font-size: 12px;
    }
</style>


<!--### Footer Part ##################################################-->
<div class="card mb-4">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
        DataTable Example
    </div>
    <div class="card-body">
        <table id="datatablesSimple">
            <thead>
            <tr>
                <th>Category </th>
                <th>Item</th>
                <th>Total Purchase</th>
                <th>Total Issue</th>
                <th>Total Purchase Price</th>
                <th>Total Issue Price</th>
                <th>Balance</th>
                <th>Issue Avg Price</th>
            </tr>
            </thead>
            <tfoot>
            <tr>
                <th>Category </th>
                <th>Item</th>
                <th>Total Purchase</th>
                <th>Total Issue</th>
                <th>Total Purchase Price</th>
                <th>Total Issue Price</th>
                <th>Balance</th>
                <th>Issue Avg Price</th>
            </tr>
            </tfoot>
            <tbody><tr>
                <th>Category </th>
                <th>Item</th>
                <th>Total Purchase</th>
                <th>Total Issue</th>
                <th>Total Purchase Price</th>
                <th>Total Issue Price</th>
                <th>Balance</th>
                <th>Issue Avg Price</th>
            </tr>
            </tbody>
        </table>
    </div>
</div>
<!----#####################################################-->